<?php
include_once "Peliculas.php";
/*
 * Acceso a datos con BD y Patr�n Singleton
 */
class AccesoDatos {
    
    private static $modelo = null;
    private $dbh = null;
    private $stmt = null;
    
    public static function initModelo(){
        if (self::$modelo == null){
            self::$modelo = new AccesoDatos();
        }
        return self::$modelo;
    }
    
    // Creo un lista de alimentos, podr�a obtenerse de una base de datos
    private function __construct(){
        
        try {
            $dsn = "mysql:host=192.168.105.83;dbname=peliculas;charset=utf8";
            $this->dbh = new PDO($dsn, "root", "root");
            $this->dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e){
            echo "Error de conexi�n ".$e->getMessage();
            exit();
        }
        // Construyo la consulta
        $this->stmt = $this->dbh->prepare("select * from peliculas where titulo = ?");
        
    }
    
    // Devuelvo la lista de Clientes
    public function obtenerListaPeliculas ($titulo):array {
        $tpelis = [];
        $this->stmt->bindValue(1,$titulo);
        // Devuelvo una tabla asociativa
        $this->stmt->setFetchMode(PDO::FETCH_ASSOC);
        if ( $this->stmt->execute() ){
            while ( $fila = $this->stmt->fetch()){
                $peli = new Peliculas();
                $peli->setTitulo  ($fila['titulo']);
                $peli->setDirector  ($fila['director']);
                $peli->setGenero  ($fila['genero']);
                $tpelis[]= $peli;
            }
        }
        return $tpelis;
    }
    
    // Evito que se pueda clonar el objeto.
    public function __clone()
    {
        trigger_error('La clonaci�n no permitida', E_USER_ERROR);
    }
}
