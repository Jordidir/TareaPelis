<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>TareaPelis</title>


		<meta name="description" content="Pelis">
		<meta name="author" content="Jorge Mu�oz Feito">
	</head>
	<body>
		<main id="container">
			<header id="header">
				<h1>Cartelera</h1><h2>- Primera entrega -</h2>
			</header>
			<section id="content">
				<?= $contenido ?>
			</section>
		</main>
	</body>
</html>