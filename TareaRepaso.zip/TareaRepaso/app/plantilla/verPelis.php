<?php
include_once 'AccesoDatos.php';

// CONTROLADOR

if (isset ($_POST['titulo'] )) {
    $titulo= $_POST['titulo'];
} else {
    $mensaje = " Introduzca un titulo de la pelicula deseada.";
    include_once 'vista.php';
    exit();
}

// Accedo al Modelo
$conexdb = AccesoDatos::initModelo();
$resultados = $conexdb->obtenerListaPeliculas($titulo);
if ( count($resultados) == 0){
    $mensaje = "No se encuentran peliculas con ese titulo.";
    unset($resultados);
}
// Cargo la vista
include_once 'vista.php';
?>