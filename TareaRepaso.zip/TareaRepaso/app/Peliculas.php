<?php

class Peliculas {
    
    private $titulo;
    private $director;
    private $genero;
    
    // Getter con m�todo m�gico
    public function __get($atributo){
        if(property_exists($this, $atributo)) {
            return $this->$atributo;
        }
    }
    // Seter manuales
    public function setTitulo(string $titulo)
    {
        $this->telefono = $titulo;
    }
    
    public function setDirector(string $director)
    {
        $this->nombre = $director;
    }
    
    public function setGenero(int $genero)
    {
        $this->puntos = $genero;
    }
    
    
    
}