<?php

function ctlUserVer (){
    $peliculas = modeloUserGetAll();
    include_once 'plantilla/verpelis.php';
}

function ctlUserInsertar () {
    include_once 'plantilla/insertar.php';
}

function ctlUserBuscar () {
    include_once 'plantilla/buscar.php';
}
?>