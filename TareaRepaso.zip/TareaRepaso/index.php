<?php
session_start();
include_once 'app/controlerUser.php';

$rutasUser = [
    "Ver"                => "ctlUserVer",
    "Insertar"                => "ctlUserInsertar",
    "Buscar"                => "ctlUserBuscar"
    
    /*
    "Inicio"                => "ctlUserInicio",
    "Detalles"              => "ctlUserDetalles",
    "Borrar"                => "ctlUserBorrar",
    "Cerrar"                => "ctlUserCerrar",
    "VerUsuarios"           => "ctlUserVerUsuarios",
    "Nuevo"                 => "ctlUserAlta",
    "Registrar"             => "ctlUserRegistrarAlta",
    "Modificar"             => "ctlUserModificar",
    "Aceptar"               => "ctlUserAceptarModificar",
    "Cambiar"               => "ctlUserCambiar",
    "Aceptar Cambios"       => "ctlUserAceptarCambiar",
    /*A partir de aqui las modificaciones de ficheros*/
    /*
    "Mis Archivos"          => "ctlUserMisArchivos",
    "BorrarArchivo"         => "ctlFileBorrarArchivo",
    "Renombrar"             => "ctlFileRenombrar",
    "DescargarArchivo"      => "ctlFileDescargarArchivo"
    */
];

$procRuta = "ctlUserVerPelis";
