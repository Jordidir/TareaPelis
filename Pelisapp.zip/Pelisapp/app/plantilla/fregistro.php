<?php

// Guardo la salida en un buffer(en memoria)
// No se envia al navegador
ob_start();
?>
<div id='aviso'><b><?= (isset($msg))?$msg:"" ?></b></div>
<form name='INSERTAR' method="POST" action="index.php?orden=Insertar">
Codigo de pelicula : <input type="number" name="codigo" value="<?= $codigo_pelicula ?>" > <br>
Titulo     : <input type="text" name="titulo" value="<?= $nombre ?>"><br>
Director : <input type="text" name="director" value="<?= $director ?>"><br>
Genero : <input type="text" name="genero" value="<?= $genero ?>"><br>
Cartel : <input type="image"    name="cartel" value="<?= $imagen ?>" ><br>

	<input type="submit" value="Almacenar">
</form>
<?php 
// Vacio el bufer y lo copio a contenido
// Para que se muestre en div de contenido
$contenido = ob_get_clean();
include_once "principal.php";

?>