<?php
// ------------------------------------------------
// Controlador que realiza la gestion de usuarios
// ------------------------------------------------

include_once 'config.php';
include_once 'modeloPeliDB.php'; 

/**********
/*
 * Inicio Muestra o procesa el formulario (POST)
 */

function  ctlPeliInicio(){
    
   }

/*
 *  Muestra y procesa el formulario de alta 
 */

function ctlPeliInsertar (){
    include_once 'plantilla/fregistro.php';
}
/*
 *  Muestra y procesa el formulario de Modificacion 
 */
function ctlPeliModificar (){
   
}



/*
 *  Muestra detalles de la pelicula
 */

function ctlPeliDetalles(){
    
    
}
/*
 * Borrar Peliculas
 */

function ctlPeliBorrar(){
   
}

/*
 * Cierra la sesión y vuelca los datos
 */
function ctlPeliCerrar(){
    session_destroy();
    modeloUserDB::closeDB();
    header('Location:index.php');
}

/*
 * Muestro la tabla con las peliculas 
 */ 
function ctlPeliVerPelis (){
    // Obtengo los datos del modelo
    $peliculas = ModeloUserDB::GetAll(); 
    // Invoco la vista 
    include_once 'plantilla/verpeliculas.php';
   
}