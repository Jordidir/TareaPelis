<?php
// ------------------------------------------------
// Controlador que realiza la gestion de usuarios
// ------------------------------------------------

include_once 'config.php';
include_once 'modeloPeliDB.php'; 

/**********
/*
 * Inicio Muestra o procesa el formulario (POST)
 */

function  ctlPeliInicio(){
    $msg = "";
    $user ="";
    $clave ="";
    if ( $_SERVER['REQUEST_METHOD'] == "POST"){
        if (isset($_POST['user']) && isset($_POST['clave'])){
            $user = $_POST['user'];
            $clave= $_POST['clave'];
            
            if ( modeloOkUser($user,$clave)){
                $_SESSION['user'] = $user;
                $_SESSION['tipouser'] = modeloObtenerTipo($user);
            
            } else {
                $msg="Error: usuario y contrase�a no v�lidos!";
            }
                   
        }
    }
    include_once 'plantilla/formAcceso.php';
}

/*
 *  Muestra y procesa el formulario de alta 
 */

function ctlPeliInsertar (){
    include_once 'plantilla/fregistro.php';
}
/*
 *  Muestra y procesa el formulario de Modificacion 
 */
function ctlPeliModificar (){
    include_once 'plantilla/fmodifica.php';
}



/*
 *  Muestra detalles de la pelicula
 */

function ctlPeliDetalles(){
    include_once 'plantilla/detalle.php';
    
}
/*
 * Borrar Peliculas
 */

function ctlPeliBorrar(){
    $id=$_GET['id'];
    ctlFileBorrarDir($id);
    modeloUserDel($id);
}

/*
 * Cierra la sesion y vuelca los datos
 */
function ctlPeliCerrar(){
    session_destroy();
    modeloUserDB::closeDB();
    header('Location:index.php');
}

/*
 * Muestro la tabla con las peliculas 
 */ 
function ctlPeliVerPelis (){
    // Obtengo los datos del modelo
    $peliculas = ModeloUserDB::GetAll(); 
    // Invoco la vista 
    include_once 'plantilla/verpeliculas.php';
   
}