<?php

// DATOS DE CONEXION
define ('DB_SERVER','localhost');
define ('DB_NAME','peliculas_db' );
define ('DB_USER','root');
define ('DB_PASSWORD','root');


    
// Definir otras constantes 