/**
 * Funciones auxiliares de javascripts 
 */

function confirmarBorrarPeli(nombre){
	  if (confirm("¿Quieres eliminar la película:  "+nombre+"?"))
	  {
	   document.location.href="./index.php?operacion=Borrar&nombre="+nombre;
	  }
	}

